"""Join price catalog and inventory by full 12 digit code, rejecting mismatches."""
import csv
import re
import sys
import unicodedata
from decimal import Decimal
from pathlib import Path
import pdfplumber
from extract_micropos import stock_rows

MONEY=re.compile(r'[\d,]+\.\d{2}')
def money(words,lo,hi,top):
    values=[w['text'] for w in words if lo<=w['x0']<=hi and abs(w['top']-top)<3 and MONEY.fullmatch(w['text'])]
    if len(values)!=1:raise ValueError(f'ambiguous price at {top}, {lo}-{hi}: {values}')
    return values[0].replace(',','')
def word(text):
    return unicodedata.normalize('NFKC',text[::-1]) if any('ARABIC' in unicodedata.name(c, '') for c in text) else text

def catalog(path):
    rows={}
    with pdfplumber.open(path) as pdf:
        for pg,page in enumerate(pdf.pages,1):
            words=page.extract_words(x_tolerance=2,y_tolerance=3)
            for a in words:
                if not (475<=a['x0']<=495 and re.fullmatch(r'\d{10}',a['text'])):continue
                tails=[w['text'] for w in words if 500<=w['x0']<=530 and 10<=w['top']-a['top']<=17 and re.fullmatch(r'\d{2}',w['text'])]
                if len(tails)!=1:raise ValueError(f'incomplete code page {pg}')
                code=a['text']+tails[0]
                if code in rows:raise ValueError(f'duplicate code {code}')
                top=a['top']
                tokens=[w for w in words if 340<=w['x0']<=475 and abs(w['top']-top)<3]
                # Wrapped names can continue under the primary line, but never into the code.
                tokens += [w for w in words if 340<=w['x0']<=475 and 10<=w['top']-top<=17 and not re.fullmatch(r'\d{2}',w['text'])]
                name=' '.join(word(w['text']) for w in sorted(tokens,key=lambda w:(round(w['top']/5),-w['x0'])))
                rows[code]={'product_code':code,'name_review':name,'purchase_price':money(words,265,340,top),'sale_price_1':money(words,180,265,top),'sale_price_2':money(words,95,180,top),'sale_price_3':money(words,0,95,top),'catalog_page':pg}
    return rows

def main():
    catalog_path,stock_path,out=map(Path,sys.argv[1:4]);prices=catalog(catalog_path);stock=stock_rows(stock_path)
    if prices.keys()!=stock.keys():raise ValueError(f'code differences: catalog_only={len(prices.keys()-stock.keys())}, stock_only={len(stock.keys()-prices.keys())}')
    rows=[]
    for code,entry in prices.items():
        s=stock[code]
        if Decimal(entry['sale_price_1'])!=Decimal(s['sale_price_1']):raise ValueError(f'sale price differs for {code}')
        rows.append({**entry,'quantity':s['quantity'],'stock_review':s['needs_review'],'stock_page':s['source_page']})
    with out.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print('matched',len(rows),'negative_stock',sum(r['stock_review']=='yes' for r in rows))
if __name__=='__main__':main()
