"""Read-only extraction of MicroPOS product and stock reports; never guesses missing fields."""
import csv
import re
import sys
from decimal import Decimal
from pathlib import Path
import pdfplumber

CODE = re.compile(r'\d{12}')
NUMBER = re.compile(r'-?[\d,]+(?:\.\d+)?')

def numeric(words, lo, hi, top):
    matches = [w['text'] for w in words if lo <= w['x0'] <= hi and abs(w['top'] - top) < 3 and NUMBER.fullmatch(w['text'])]
    if len(matches) != 1:
        raise ValueError(f'Expected one numeric cell at y={top}, x={lo}-{hi}, got {matches}')
    return matches[0].replace(',', '')

def stock_rows(path):
    result = {}
    with pdfplumber.open(path) as pdf:
        for number, page in enumerate(pdf.pages, 1):
            words = page.extract_words(x_tolerance=2, y_tolerance=3)
            for anchor in words:
                if not (440 <= anchor['x0'] <= 470 and CODE.fullmatch(anchor['text'])):
                    continue
                code = anchor['text']
                if code in result: raise ValueError(f'Duplicate stock code {code}')
                qty = numeric(words, 132, 175, anchor['top'])
                price = numeric(words, 188, 240, anchor['top'])
                # Keep negative source balances for review; do not silently clamp to zero.
                result[code] = {'product_code': code, 'quantity': qty, 'sale_price_1': price, 'source_page': number, 'needs_review': 'yes' if Decimal(qty) < 0 else 'no'}
    return result

def main():
    src, dst = map(Path, sys.argv[1:3])
    rows = stock_rows(src)
    with dst.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=['product_code','quantity','sale_price_1','source_page','needs_review'])
        writer.writeheader(); writer.writerows(rows.values())
    print('rows:', len(rows), 'unique:', len(set(rows)), 'positive_stock:', sum(Decimal(v['quantity']) > 0 for v in rows.values()), 'negative_stock:', sum(Decimal(v['quantity']) < 0 for v in rows.values()))

if __name__ == '__main__': main()
