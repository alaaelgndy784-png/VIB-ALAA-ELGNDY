"""Preflight and optional first-time Firestore import using application default credentials.

No Firebase key is stored in this project. The apply path refuses populated targets.
"""
import argparse
import csv
from decimal import Decimal
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def rows(name):
    with (ROOT/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def load():
    products=rows('products_2026-09-24.csv')
    customers=rows('customer_opening_2026-09-24.csv')
    suppliers=rows('supplier_opening_2026-09-24.csv')
    assert len(products)==len({r['product_code'] for r in products})==1151
    assert len(customers)==32 and sum(Decimal(r['total_balance']) for r in customers)==Decimal('755256.52')
    assert len(suppliers)==13 and sum(Decimal(r['total_balance']) for r in suppliers)==Decimal('670497.78')
    assert sum(Decimal(r['quantity'])<0 for r in products)==21
    return products,customers,suppliers

def main():
    p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');p.add_argument('--project-id')
    args=p.parse_args();products,customers,suppliers=load()
    print(f'Preflight: {len(products)} products, {len(customers)} customers, {len(suppliers)} suppliers, 21 negative stocks preserved.')
    if not args.apply:return
    if not args.project_id:raise SystemExit('Specify --project-id before --apply')
    import firebase_admin
    from firebase_admin import firestore
    firebase_admin.initialize_app(options={'projectId':args.project_id})
    db=firestore.client()
    marker=db.collection('imports').document('micropos-2026-09-24')
    if marker.get().exists:raise SystemExit('Snapshot already imported or in progress; inspect manually before retry')
    for col in ('products','stock','customers','suppliers'):
        if next(db.collection(col).limit(1).stream(),None) is not None:
            raise SystemExit(f'{col} is populated; import refused to avoid overwrites')
    # Reserve the snapshot identity before any writes. On failure, an operator
    # must reconcile partial deterministic IDs before retrying.
    marker.create({'status':'in_progress','counts':{'products':len(products),'customers':len(customers),'suppliers':len(suppliers)}})
    operations=[]
    for r in products:
        code=r['product_code'];q=int(Decimal(r['quantity']))
        operations.append((db.collection('products').document(code),{
            'name':r['name_review'],'code':code,'price':float(r['sale_price_1']),
            'purchasePrice':float(r['purchase_price']),
            'salePrice2':float(r['sale_price_2']),'salePrice3':float(r['sale_price_3']),
            'active':True,'source':'MicroPOS 2026-09-24'}))
        operations.append((db.collection('stock').document('main_'+code),{
            'branchId':'main','productId':code,'quantity':q}))
    for collection,items in [('customers',customers),('suppliers',suppliers)]:
        for r in items:
            balance=float(r['total_balance'])
            operations.append((db.collection(collection).document('micropos-'+r['number']),{
                'name':r['name'],'phone':r['phone_raw'],
                'openingBalance':balance,'balance':balance,
                'invoiceBalance':float(r['invoice_balance']),
                'otherOpeningBalance':float(r['other_opening_balance']),
                'source':'MicroPOS 2026-09-24'}))
    # Keep batches well beneath the Firestore operation limit.
    for start in range(0,len(operations),400):
        batch=db.batch()
        for ref,data in operations[start:start+400]:batch.create(ref,data)
        batch.commit()
    marker.update({'status':'completed','documentCount':len(operations)})
    print('Import completed and recorded')
if __name__=='__main__':main()
