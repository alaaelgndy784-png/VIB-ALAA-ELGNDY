"""Extract customer/supplier opening balances from the two MicroPOS debt PDFs."""
import csv
import re
import sys
import unicodedata
from decimal import Decimal
from pathlib import Path
import pdfplumber

MONEY = re.compile(r'-?[\d,]+\.\d{2}')

def arabic_word(raw):
    return unicodedata.normalize('NFKC', raw[::-1]) if any('ARABIC' in unicodedata.name(ch, '') for ch in raw) else raw

def cell(words, start, end, top):
    matched = [w['text'] for w in words if start <= w['x0'] <= end and abs(w['top']-top)<3 and MONEY.fullmatch(w['text'])]
    if len(matched)!=1: raise ValueError(f'ambiguous money cell at {top}: {matched}')
    return Decimal(matched[0].replace(',',''))

def read(path):
    result=[]
    with pdfplumber.open(path) as pdf:
        for page_number,page in enumerate(pdf.pages,1):
            words=page.extract_words(x_tolerance=2,y_tolerance=3)
            anchors=[w for w in words if w['x0']>550 and re.fullmatch(r'\d+',w['text'])]
            for anchor in anchors:
                top=anchor['top']
                try: total=cell(words,0,120,top)
                except ValueError: continue
                due=cell(words,255,380,top)
                opening=cell(words,145,255,top)
                if total!=due+opening: raise ValueError(f'balance mismatch on page {page_number}, row {anchor["text"]}')
                name_words=[w for w in words if 380<=w['x0']<550 and abs(w['top']-top)<3]
                name=' '.join(arabic_word(w['text']) for w in sorted(name_words,key=lambda w:-w['x0']))
                if not name: raise ValueError('missing name')
                continuation=[w for w in words if 390<=w['x0']<550 and 9<w['top']-top<16 and not re.search(r'\d',w['text']) and ':ﺕ' not in w['text']]
                if continuation: name+=' '+' '.join(arabic_word(w['text']) for w in sorted(continuation,key=lambda w:-w['x0']))
                nearby=[w['text'] for w in words if 380<=w['x0']<550 and 9<w['top']-top<19]
                phone=next((re.sub(r'[^0-9+]','',x) for x in nearby if ':ﺕ' in x), '')
                result.append({'number':int(anchor['text']),'name':name,'phone_raw':phone,'invoice_balance':str(due),'other_opening_balance':str(opening),'total_balance':str(total),'source_page':page_number})
    numbers=[v['number'] for v in result]
    if numbers!=list(range(1,len(result)+1)): raise ValueError('missing or repeated account number')
    return result

def main():
    source,dest=map(Path,sys.argv[1:3]);rows=read(source)
    with dest.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print('accounts',len(rows),'total',sum(Decimal(r['total_balance']) for r in rows),'unverified phones',sum(not r['phone_raw'] for r in rows))
if __name__=='__main__':main()
