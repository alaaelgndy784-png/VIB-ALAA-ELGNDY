import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const VibApp());
}

const gold = Color(0xFFD6AC55);
final db = FirebaseFirestore.instance;

class VibApp extends StatelessWidget {
  const VibApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'VIB المبيعات',
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xFF111111),
      colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF171717), foregroundColor: gold),
    ),
    home: const Directionality(textDirection: TextDirection.rtl, child: Gate()),
  );
}

class Gate extends StatelessWidget {
  const Gate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (context, auth) {
      if (!auth.hasData) return const LoginPage();
      return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: db.collection('users').doc(auth.data!.uid).snapshots(),
        builder: (context, user) {
          if (user.hasError) return const Center(child: Text('تعذر تحميل الحساب'));
          if (!user.hasData) return const Center(child: CircularProgressIndicator());
          final data = user.data!.data();
          if (data == null || data['active'] != true || !['owner', 'employee'].contains(data['role'])) {
            return Scaffold(body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('الحساب غير مفعّل. المدير يحدد فرعك ويفعّل دخولك.'),
              if (data == null) FilledButton(
                onPressed: () async {
                  final person = FirebaseAuth.instance.currentUser;
                  final email = person?.email ?? '';
                  final rawPhone = email.split('@').first;
                  if (person == null || rawPhone.isEmpty) return;
                  final accountPhone = '+$rawPhone';
                  try {
                    await db.collection('users').doc(person.uid).set({
                      'role': 'pending', 'active': false, 'name': accountPhone,
                      'phone': accountPhone, 'createdAt': FieldValue.serverTimestamp(),
                    });
                  } catch (_) {
                    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('تعذر إرسال طلب التفعيل')));
                  }
                },
                child: const Text('طلب تفعيل الحساب'),
              ),
              TextButton(onPressed: () => FirebaseAuth.instance.signOut(), child: const Text('خروج')),
            ])));
          }
          return Home(uid: auth.data!.uid, role: data['role'] as String, branchId: (data['branchId'] ?? '') as String, name: (data['name'] ?? '') as String);
        },
      );
    },
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final phone = TextEditingController(), pin = TextEditingController();
  String? error;
  bool busy = false;
  String? normalizedPhone() {
    var value = phone.text.replaceAll(RegExp(r'\D'), '');
    if (value.startsWith('00')) value = value.substring(2);
    if (value.startsWith('0')) value = '20${value.substring(1)}';
    if (!value.startsWith('20') || value.length != 12) return null;
    return '+$value';
  }

  String emailFor(String value) => '${value.replaceAll('+', '')}@vib.local';

  Future<void> login({required bool create}) async {
    setState(() { busy = true; error = null; });
    try {
      final number = normalizedPhone();
      final password = pin.text.trim();
      if (number == null) throw Exception('اكتب رقم مصري صحيح مثل 01012345678');
      if (!RegExp(r'^\d{6,}$').hasMatch(password)) throw Exception('الرقم السري لازم يكون 6 أرقام على الأقل');
      if (create) {
        final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: emailFor(number), password: password);
        await db.collection('users').doc(credential.user!.uid).set({
          'role': 'pending', 'active': false, 'name': number, 'phone': number,
          'createdAt': FieldValue.serverTimestamp(),
        });
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: emailFor(number), password: password);
      }
    } on FirebaseAuthException catch (e) {
      final message = switch (e.code) {
        'user-not-found' || 'invalid-credential' => 'الرقم أو الرقم السري غير صحيح',
        'email-already-in-use' => 'الرقم مسجل بالفعل؛ اضغط دخول',
        'weak-password' => 'اختر رقمًا سريًا أقوى',
        _ => e.message ?? 'تعذر تسجيل الدخول',
      };
      if (mounted) setState(() => error = message);
    } catch (e) {
      if (mounted) setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
  @override
  Widget build(BuildContext context) => Scaffold(body: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420), child: Padding(
    padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Text('VIB', style: TextStyle(fontSize: 52, fontWeight: FontWeight.bold, color: gold)),
      const Text('المبيعات والمخزون', style: TextStyle(fontSize: 20)), const SizedBox(height: 28),
      TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف المصري')),
      const SizedBox(height: 12),
      TextField(controller: pin, obscureText: true, keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'رقم سري من 6 أرقام أو أكثر')),
      if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
      const SizedBox(height: 18),
      FilledButton(onPressed: busy ? null : () => login(create: false), child: const Text('دخول')),
      TextButton(onPressed: busy ? null : () => login(create: true), child: const Text('إنشاء حساب جديد')),
      const Text('التسجيل مجاني ولا يرسل رسالة SMS. المدير يفعّل حساب الموظف ويحدد فرعه.'),
    ]),
  ))));
}

class Home extends StatefulWidget {
  final String uid, role, branchId, name;
  const Home({super.key, required this.uid, required this.role, required this.branchId, required this.name});
  @override
  State<Home> createState() => _HomeState();
}
class _HomeState extends State<Home> {
  int page = 0;
  @override
  Widget build(BuildContext context) {
    final owner = widget.role == 'owner';
    final labels = owner ? ['المنتجات', 'المبيعات', 'الفروع', 'الموظفون', 'الذمم'] : ['المنتجات', 'مبيعاتي'];
    return Scaffold(
      appBar: AppBar(title: Text('VIB | ${widget.name}'), actions: [IconButton(tooltip: 'خروج', onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout))]),
      body: switch(page) {
        0 => Products(owner: owner, uid: widget.uid, branchId: widget.branchId),
        1 => Sales(owner: owner, branchId: widget.branchId),
        2 => const Branches(),
        3 => const Staff(),
        _ => const Accounts(),
      },
      bottomNavigationBar: NavigationBar(selectedIndex: page, onDestinationSelected: (i) => setState(() => page = i), destinations: [
        const NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'المنتجات'),
        NavigationDestination(icon: const Icon(Icons.receipt_long_outlined), label: labels[1]),
        if (owner) const NavigationDestination(icon: Icon(Icons.store_outlined), label: 'الفروع'),
        if (owner) const NavigationDestination(icon: Icon(Icons.people_outline), label: 'الموظفون'),
        if (owner) const NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'الذمم'),
      ]),
    );
  }
}

class Products extends StatelessWidget {
  final bool owner;
  final String uid, branchId;
  const Products({super.key, required this.owner, required this.uid, required this.branchId});
  @override
  Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: db.collection('products').snapshots(),
    builder: (context, snap) {
      if (snap.hasError) return const Center(child: Text('تعذر تحميل المنتجات'));
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final docs = snap.data!.docs.where((d) => d.data()['active'] == true).toList();
      return Column(children: [
        if (owner) Padding(padding: const EdgeInsets.all(12), child: FilledButton.icon(onPressed: () => productDialog(context), icon: const Icon(Icons.add), label: const Text('إضافة منتج'))),
        Expanded(child: docs.isEmpty ? const Center(child: Text('لا توجد منتجات بعد')) : ListView.builder(itemCount: docs.length, itemBuilder: (context, i) {
          final d = docs[i], p = d.data();
          return ListTile(title: Text('${p['name'] ?? ''}'), subtitle: Text('السعر: ${p['price'] ?? 0} ج.م'), trailing: owner
            ? Wrap(children: [IconButton(tooltip: 'تعديل', icon: const Icon(Icons.edit), onPressed: () => productDialog(context, id: d.id, data: p)), IconButton(tooltip: 'المخزون الرئيسي', icon: const Icon(Icons.warehouse), onPressed: () => mainStockDialog(context, d.id, '${p['name']}'))])
            : IconButton(icon: const Icon(Icons.add_shopping_cart), onPressed: () => saleDialog(context, d.id, p, uid, branchId)));
        })),
      ]);
    },
  );
}

Future<void> productDialog(BuildContext context, {String? id, Map<String, dynamic>? data}) async {
  final name = TextEditingController(text: '${data?['name'] ?? ''}');
  final price = TextEditingController(text: '${data?['price'] ?? ''}');
  await showDialog<void>(context: context, builder: (dialogContext) => AlertDialog(title: Text(id == null ? 'منتج جديد' : 'تعديل المنتج'), content: Column(mainAxisSize: MainAxisSize.min, children: [
    TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم المنتج')),
    TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعر')),
  ]), actions: [
    TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
    FilledButton(onPressed: () async {
      final amount = double.tryParse(price.text);
      if (name.text.trim().isEmpty || amount == null || amount < 0) return;
      final ref = id == null ? db.collection('products').doc() : db.collection('products').doc(id);
      try { await ref.set({'name': name.text.trim(), 'price': amount, 'active': true, 'updatedAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));
        if (dialogContext.mounted) Navigator.pop(dialogContext);
      } catch (_) { if (dialogContext.mounted) ScaffoldMessenger.of(dialogContext).showSnackBar(const SnackBar(content: Text('فشل حفظ المنتج'))); }
    }, child: const Text('حفظ')),
  ]));
}

Future<void> saleDialog(BuildContext context, String productId, Map<String, dynamic> product, String uid, String branchId) async {
  final quantity = TextEditingController(text: '1');
  await showDialog<void>(context: context, builder: (dialogContext) => AlertDialog(title: Text('بيع ${product['name']}'), content: TextField(controller: quantity, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الكمية')),
    actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')), FilledButton(onPressed: () async {
      final qty = int.tryParse(quantity.text);
      if (qty == null || qty <= 0) return;
      try {
        await db.runTransaction((tx) async {
          final stockRef = db.collection('stock').doc('${branchId}_$productId');
          final stock = await tx.get(stockRef);
          final current = (stock.data()?['quantity'] as num?)?.toInt() ?? 0;
          if (current < qty) throw Exception('الكمية غير متاحة في الفرع');
          final sale = db.collection('sales').doc();
          tx.update(stockRef, {'quantity': current - qty, 'lastSaleId': sale.id});
          tx.set(sale, {'branchId': branchId, 'employeeId': uid, 'productId': productId, 'productName': product['name'], 'quantity': qty, 'unitPrice': product['price'], 'total': qty * (product['price'] as num), 'createdAt': FieldValue.serverTimestamp()});
        });
        if (dialogContext.mounted) Navigator.pop(dialogContext);
      } catch (e) { if (dialogContext.mounted) ScaffoldMessenger.of(dialogContext).showSnackBar(SnackBar(content: Text('تعذر البيع: $e'))); }
    }, child: const Text('تأكيد البيع'))]));
}

class Sales extends StatelessWidget {
  final bool owner;
  final String branchId;
  const Sales({super.key, required this.owner, required this.branchId});
  @override
  Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: (owner ? db.collection('sales') : db.collection('sales').where('branchId', isEqualTo: branchId)).snapshots(),
    builder: (context, snap) {
    if (snap.hasError) return const Center(child: Text('تعذر عرض المبيعات'));
    if (!snap.hasData) return const Center(child: CircularProgressIndicator());
    final rows = snap.data!.docs.where((d) => owner || d.data()['branchId'] == branchId).toList()..sort((a,b) => ((b.data()['createdAt'] as Timestamp?)?.millisecondsSinceEpoch ?? 0).compareTo((a.data()['createdAt'] as Timestamp?)?.millisecondsSinceEpoch ?? 0));
    if (rows.isEmpty) return const Center(child: Text('لا توجد مبيعات بعد'));
    return ListView(children: rows.map((d) { final s = d.data(); return ListTile(title: Text('${s['productName']} × ${s['quantity']}'), subtitle: Text('فرع: ${s['branchId']} • ${s['createdAt'] is Timestamp ? DateFormat('dd/MM/yyyy HH:mm').format((s['createdAt'] as Timestamp).toDate()) : 'جارٍ الحفظ'}'), trailing: Text('${s['total']} ج.م')); }).toList());
  });
}

class Branches extends StatelessWidget {
  const Branches({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: db.collection('branches').snapshots(), builder: (context, snap) {
    if (!snap.hasData) return const Center(child: CircularProgressIndicator());
    return Column(children: [FilledButton.icon(onPressed: () => branchDialog(context), icon: const Icon(Icons.add), label: const Text('فرع جديد')), Expanded(child: ListView(children: snap.data!.docs.map((d) => ListTile(title: Text('${d.data()['name'] ?? d.id}'), subtitle: Text('رمز الفرع: ${d.id}'), trailing: IconButton(icon: const Icon(Icons.inventory), onPressed: () => stockDialog(context, d.id)))).toList()))]);
  });
}
Future<void> branchDialog(BuildContext context) async {
  final name = TextEditingController();
  await showDialog<void>(context: context, builder: (c) => AlertDialog(title: const Text('فرع جديد'), content: TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الفرع')), actions: [FilledButton(onPressed: () async { if (name.text.trim().isEmpty) return; await db.collection('branches').add({'name': name.text.trim(), 'active': true}); if (c.mounted) Navigator.pop(c); }, child: const Text('حفظ'))]));
}
Future<void> stockDialog(BuildContext context, String branchId) async {
  final id = TextEditingController(), qty = TextEditingController();
  await showDialog<void>(context: context, builder: (c) => AlertDialog(title: const Text('نقل من المخزون الرئيسي'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: id, decoration: const InputDecoration(labelText: 'رمز المنتج')), TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الكمية'))]), actions: [FilledButton(onPressed: () async {
    final q = int.tryParse(qty.text), p = id.text.trim(); if (q == null || q <= 0 || p.isEmpty) return;
    try { await db.runTransaction((tx) async {
      final mainRef = db.collection('stock').doc('main_$p'), branchRef = db.collection('stock').doc('${branchId}_$p');
      final main = await tx.get(mainRef), branch = await tx.get(branchRef);
      final available = (main.data()?['quantity'] as num?)?.toInt() ?? 0;
      if (available < q) throw Exception('المخزون الرئيسي غير كافٍ');
      tx.set(mainRef, {'branchId': 'main', 'productId': p, 'quantity': available - q});
      tx.set(branchRef, {'branchId': branchId, 'productId': p, 'quantity': ((branch.data()?['quantity'] as num?)?.toInt() ?? 0) + q});
    }); if (c.mounted) Navigator.pop(c);
    } catch (e) { if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('$e'))); }
  }, child: const Text('نقل'))]));
}

class Staff extends StatelessWidget {
  const Staff({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: db.collection('users').snapshots(), builder: (context, snap) {
    if (!snap.hasData) return const Center(child: CircularProgressIndicator());
    return ListView(children: snap.data!.docs.map((d) {
      final data = d.data();
      return ListTile(
        title: Text('${data['name'] ?? data['phone'] ?? d.id}'),
        subtitle: Text('${data['phone'] ?? ''} • ${data['role'] == 'pending' ? 'بانتظار التفعيل' : (data['branchId'] ?? 'المدير')}'),
        trailing: data['role'] == 'owner' ? const Icon(Icons.verified_user) :
          TextButton(onPressed: () => assignEmployee(context, d.id, data), child: const Text('تحديد الفرع')),
      );
    }).toList());
  });
}

Future<void> assignEmployee(BuildContext context, String uid, Map<String, dynamic> data) async {
  final name = TextEditingController(text: '${data['name'] ?? ''}');
  final branches = await db.collection('branches').get();
  if (!context.mounted) return;
  if (branches.docs.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أضف فرعًا أولًا')));
    return;
  }
  String selected = branches.docs.any((d) => d.id == data['branchId'])
      ? data['branchId'] as String : branches.docs.first.id;
  bool enabled = data['active'] == true;
  await showDialog<void>(context: context, builder: (dialogContext) => StatefulBuilder(
    builder: (c, setDialogState) => AlertDialog(
      title: const Text('صلاحيات الموظف'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الموظف')),
        DropdownButtonFormField<String>(initialValue: selected,
          decoration: const InputDecoration(labelText: 'الفرع'),
          items: branches.docs.map((d) => DropdownMenuItem(value: d.id, child: Text('${d.data()['name']}'))).toList(),
          onChanged: (v) { if (v != null) setDialogState(() => selected = v); }),
        SwitchListTile(title: const Text('تفعيل الدخول'), value: enabled,
          onChanged: (v) => setDialogState(() => enabled = v)),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
        FilledButton(onPressed: () async {
          if (name.text.trim().isEmpty) return;
          try {
            await db.collection('users').doc(uid).update({
              'name': name.text.trim(), 'role': 'employee', 'branchId': selected, 'active': enabled,
            });
            if (c.mounted) Navigator.pop(c);
          } catch (_) {
            if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('تعذر حفظ صلاحيات الموظف')));
          }
        }, child: const Text('حفظ'))],
    ),
  ));
}

Future<void> mainStockDialog(BuildContext context, String productId, String name) async {
  final desired = TextEditingController();
  final reason = TextEditingController();
  final stockRef = db.collection('stock').doc('main_$productId');
  final current = await stockRef.get();
  if (!context.mounted) return;
  final original = (current.data()?['quantity'] as num?)?.toInt() ?? 0;
  desired.text = '$original';
  await showDialog<void>(context: context, builder: (c) => AlertDialog(
    title: Text('تسوية المخزون الرئيسي: $name'),
    content: Column(mainAxisSize: MainAxisSize.min, children: [
      Text('الرصيد الحالي: $original'),
      TextField(controller: desired, keyboardType: const TextInputType.numberWithOptions(signed: true),
        decoration: const InputDecoration(labelText: 'الرصيد الصحيح بعد التسوية')),
      TextField(controller: reason, maxLength: 160,
        decoration: const InputDecoration(labelText: 'سبب التسوية')),
    ]),
    actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')), FilledButton(onPressed: () async {
      final target = int.tryParse(desired.text.trim());
      if (target == null || reason.text.trim().isEmpty) {
        ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('اكتب الرصيد الصحيح وسبب التسوية')));
        return;
      }
      try {
        await db.runTransaction((tx) async {
          final snapshot = await tx.get(stockRef);
          final before = (snapshot.data()?['quantity'] as num?)?.toInt() ?? 0;
          if (before != original) throw Exception('الرصيد اتغير؛ افتح التسوية مرة تانية');
          if (before == target) throw Exception('الرصيد الجديد مطابق للحالي');
          tx.set(stockRef, {'branchId': 'main', 'productId': productId, 'quantity': target});
          tx.set(db.collection('stockAdjustments').doc(), {
            'productId': productId, 'productName': name, 'branchId': 'main',
            'before': before, 'after': target, 'delta': target - before,
            'reason': reason.text.trim(), 'actorId': FirebaseAuth.instance.currentUser!.uid,
            'createdAt': FieldValue.serverTimestamp(),
          });
        });
        if (c.mounted) Navigator.pop(c);
      } catch (e) { if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('تعذر التسوية: $e'))); }
    }, child: const Text('حفظ التسوية'))],
  ));
}

class Accounts extends StatefulWidget {
  const Accounts({super.key});
  @override
  State<Accounts> createState() => _AccountsState();
}
class _AccountsState extends State<Accounts> {
  bool suppliers = false;
  @override
  Widget build(BuildContext context) {
    final collection = suppliers ? 'suppliers' : 'customers';
    return Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: SegmentedButton<bool>(
        segments: const [ButtonSegment(value: false, label: Text('العملاء')), ButtonSegment(value: true, label: Text('الموردون'))],
        selected: {suppliers}, onSelectionChanged: (values) => setState(() => suppliers = values.first))),
      Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: db.collection(collection).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Center(child: Text('تعذر تحميل الذمم'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs.toList()..sort((a,b) =>
              '${a.data()['name'] ?? ''}'.compareTo('${b.data()['name'] ?? ''}'));
          if (docs.isEmpty) return const Center(child: Text('لا توجد حسابات بعد'));
          return ListView.builder(itemCount: docs.length, itemBuilder: (context, index) {
            final d = docs[index], account = d.data();
            return ListTile(
              title: Text('${account['name'] ?? ''}'),
              subtitle: Text('هاتف: ${account['phone'] ?? 'غير مسجل'}'),
              trailing: Column(mainAxisAlignment: MainAxisAlignment.center, mainAxisSize: MainAxisSize.min, children: [
                Text('${account['balance'] ?? 0} ج.م', style: const TextStyle(color: gold, fontWeight: FontWeight.bold)),
                const Text('الرصيد الحالي'),
              ]),
              onTap: () => accountDialog(context, collection, d.id, account),
            );
          });
        },
      )),
    ]);
  }
}

Future<void> accountDialog(BuildContext context, String collection, String id, Map<String, dynamic> account) async {
  final amount = TextEditingController();
  final isSupplier = collection == 'suppliers';
  await showDialog<void>(context: context, builder: (dialogContext) => AlertDialog(
    title: Text('${account['name'] ?? ''}'),
    content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('رصيد البداية: ${account['openingBalance'] ?? 0} ج.م'),
      Text('الرصيد الحالي: ${account['balance'] ?? 0} ج.م'),
      const SizedBox(height: 14),
      TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(labelText: isSupplier ? 'مبلغ السداد' : 'مبلغ التحصيل')),
    ]),
    actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
      FilledButton(onPressed: () async {
        final paid = double.tryParse(amount.text.trim());
        if (paid == null || !paid.isFinite || paid <= 0) return;
        try {
          await db.runTransaction((tx) async {
            final ref = db.collection(collection).doc(id);
            final snapshot = await tx.get(ref);
            final balance = (snapshot.data()?['balance'] as num?)?.toDouble();
            if (balance == null || paid > balance) throw Exception('المبلغ أكبر من الرصيد الحالي');
            tx.update(ref, {'balance': balance - paid, 'updatedAt': FieldValue.serverTimestamp()});
            tx.set(db.collection('accountMovements').doc(), {
              'accountType': collection, 'accountId': id, 'accountName': snapshot.data()?['name'],
              'kind': isSupplier ? 'payment' : 'collection', 'amount': paid,
              'balanceBefore': balance, 'balanceAfter': balance - paid,
              'createdAt': FieldValue.serverTimestamp(),
              'actorId': FirebaseAuth.instance.currentUser!.uid,
            });
          });
          if (dialogContext.mounted) Navigator.pop(dialogContext);
        } catch (e) {
          if (dialogContext.mounted) ScaffoldMessenger.of(dialogContext).showSnackBar(SnackBar(content: Text('تعذر تسجيل الحركة: $e')));
        }
      }, child: Text(isSupplier ? 'تسجيل السداد' : 'تسجيل التحصيل'))],
  ));
}
