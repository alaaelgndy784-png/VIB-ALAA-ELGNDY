package com.vib.accounts

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.RemoveShoppingCart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material3.Checkbox
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Gold = Color(0xFFD4AF37)
private val Dark = Color(0xFF090909)
private val Panel = Color(0xFF171717)

enum class AccountsPage(val title: String) {
  HOME("الرئيسية"), SALES("المبيعات"), PURCHASES("المشتريات"), CUSTOMERS("العملاء"),
  SUPPLIERS("الموردين"), CASH("الصندوق"), EXPENSES("المصروفات"), INVENTORY("المخزون"),
  REPORTS("الاستعلامات والتقارير"), USERS("الموظفون والصلاحيات"), SETTINGS("الإعدادات")
}

@Composable
fun VibAccountsApp() {
  val context = LocalContext.current
  val store = remember { AccountsStore(context.applicationContext) }
  val state by store.state.collectAsState()
  var page by remember { mutableStateOf(AccountsPage.HOME) }
  if (state.signedInUser == null) {
    LoginScreen(store)
    return
  }
  AccountsShell(page, { page = it }, state, store)
}

@Composable
private fun LoginScreen(store: AccountsStore) {
  var code by remember { mutableStateOf(if (BuildConfig.APP_ROLE == "MANAGER") "admin" else "") }
  var password by remember { mutableStateOf("") }
  var error by remember { mutableStateOf("") }
  Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, Gold)) {
      Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("VIB", color = Gold, fontWeight = FontWeight.Black, fontSize = 52.sp)
        Text("برنامج الحسابات والمخزون", fontSize = 20.sp)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
          value = password, onValueChange = { password = it; error = "" },
          label = { Text("كلمة المرور أو PIN") }, singleLine = true,
          visualTransformation = PasswordVisualTransformation(),
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
        )
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(code, { code = it; error = "" }, label = { Text("كود الدخول") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { store.signIn(code, password) { message -> error = message.orEmpty() } }, modifier = Modifier.fillMaxWidth()) {
          Text("دخول")
        }
        if (BuildConfig.APP_ROLE == "MANAGER") Text("المدير: admin / 1234", color = Color.Gray, fontSize = 12.sp)
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AccountsShell(page: AccountsPage, go: (AccountsPage) -> Unit, state: AccountsState, store: AccountsStore) {
  val snackbar = remember { SnackbarHostState() }
  Scaffold(
    snackbarHost = { SnackbarHost(snackbar) },
    topBar = {
      TopAppBar(
        title = { Column { Text("VIB Accounts", color = Gold, fontWeight = FontWeight.Bold); Text(page.title, fontSize = 12.sp) } },
        navigationIcon = {
          IconButton(onClick = { if (page == AccountsPage.HOME) Unit else go(AccountsPage.HOME) }) {
            Icon(if (page == AccountsPage.HOME) Icons.Default.Menu else Icons.Default.ArrowBack, null)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Dark)
      )
    }
  ) { padding ->
    Box(Modifier.padding(padding).fillMaxSize()) {
      when (page) {
        AccountsPage.HOME -> HomePage(state, go)
        AccountsPage.SALES -> MovementPage(EntryType.SALE, state, store, snackbar)
        AccountsPage.PURCHASES -> MovementPage(EntryType.PURCHASE, state, store, snackbar)
        AccountsPage.CUSTOMERS -> PartiesPage(true, state, store)
        AccountsPage.SUPPLIERS -> PartiesPage(false, state, store)
        AccountsPage.CASH -> CashPage(state, store, snackbar)
        AccountsPage.EXPENSES -> SimpleEntryPage(EntryType.EXPENSE, state, store, snackbar)
        AccountsPage.INVENTORY -> InventoryPage(state, store)
        AccountsPage.REPORTS -> ReportsPage(state, store)
        AccountsPage.USERS -> UsersPage(state, store)
        AccountsPage.SETTINGS -> SettingsPage(state, store)
      }
    }
  }
}

@Composable
private fun HomePage(state: AccountsState, go: (AccountsPage) -> Unit) {
  val user = state.signedInUser ?: return
  val cards = listOfNotNull(
    if (user.can(AppPermission.SALES)) Triple(AccountsPage.SALES, Icons.Default.ShoppingCart, "فواتير البيع والمرتجعات") else null,
    if (user.can(AppPermission.PURCHASES)) Triple(AccountsPage.PURCHASES, Icons.Default.Store, "فواتير الشراء والتوريد") else null,
    if (user.can(AppPermission.CUSTOMERS)) Triple(AccountsPage.CUSTOMERS, Icons.Default.Person, "الحسابات والمديونيات") else null,
    if (user.can(AppPermission.SUPPLIERS)) Triple(AccountsPage.SUPPLIERS, Icons.Default.People, "حسابات الموردين") else null,
    if (user.can(AppPermission.CASH_RECEIPT) || user.can(AppPermission.CASH_PAYMENT)) Triple(AccountsPage.CASH, Icons.Default.Payments, "قبض وصرف ورصيد") else null,
    if (user.can(AppPermission.EXPENSES)) Triple(AccountsPage.EXPENSES, Icons.Default.RemoveShoppingCart, "تسجيل المصروفات") else null,
    if (user.can(AppPermission.INVENTORY)) Triple(AccountsPage.INVENTORY, Icons.Default.Inventory2, "المخزن الرئيسي المشترك") else null,
    if (user.can(AppPermission.REPORTS)) Triple(AccountsPage.REPORTS, Icons.Default.Assessment, "تقارير الحركة والأرباح") else null,
    if (user.can(AppPermission.MANAGE_USERS)) Triple(AccountsPage.USERS, Icons.Default.ManageAccounts, "إضافة موظف وتحديد صلاحياته") else null,
    if (user.can(AppPermission.SETTINGS)) Triple(AccountsPage.SETTINGS, Icons.Default.Settings, "النسخ الاحتياطي والحالة") else null
  )
  LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
    item {
      Card(colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, Gold), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
          Text("VIB للتجارة والتوزيع", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
          Text("المستخدم: ${user.name}", color = Color.White)
          Text(state.cloudStatus, color = if (state.cloudStatus.contains("متصل")) Color(0xFF72D38B) else Color(0xFFFFC857))
          Spacer(Modifier.height(8.dp))
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            SummaryValue("المبيعات", state.salesTotal)
            SummaryValue("رصيد الصندوق", state.cashBalance)
          }
        }
      }
      Spacer(Modifier.height(12.dp))
    }
    items(cards.chunked(2)) { row ->
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        row.forEach { (target, icon, subtitle) ->
          Card(
            modifier = Modifier.weight(1f).height(150.dp).clickable { go(target) },
            colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, Color(0xFF4A4A4A))
          ) {
            Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
              Icon(icon, null, tint = Gold)
              Spacer(Modifier.height(8.dp))
              Text(target.title, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center)
              Text(subtitle, color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center)
            }
          }
        }
        if (row.size == 1) Spacer(Modifier.weight(1f))
      }
      Spacer(Modifier.height(10.dp))
    }
  }
}

@Composable
private fun SummaryValue(label: String, amount: Double) {
  Column { Text(label, color = Color.Gray); Text(money(amount), color = Gold, fontWeight = FontWeight.Bold) }
}

@Composable
private fun MovementPage(type: EntryType, state: AccountsState, store: AccountsStore, snackbar: SnackbarHostState) {
  var dialog by remember { mutableStateOf(false) }
  val entries = state.entries.filter { it.type == type }
  Box(Modifier.fillMaxSize()) {
    EntryList(entries, store)
    FloatingActionButton(onClick = { dialog = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp), containerColor = Gold) { Icon(Icons.Default.Add, null) }
  }
  if (dialog) MovementDialog(type, state, onDismiss = { dialog = false }) { party, product, qty, price, note ->
    val error = store.recordMovement(type, party, product, qty, price, 0.0, note)
    if (error == null) dialog = false
  }
}

@Composable
private fun MovementDialog(type: EntryType, state: AccountsState, onDismiss: () -> Unit, save: (Party?, StockItem?, Int, Double, String) -> Unit) {
  val parties = if (type == EntryType.SALE) state.customers else state.suppliers
  var selectedParty by remember { mutableStateOf<Party?>(null) }
  var selectedProduct by remember { mutableStateOf<StockItem?>(state.products.firstOrNull()) }
  var qty by remember { mutableStateOf("1") }
  var price by remember(selectedProduct) { mutableStateOf(if (type == EntryType.SALE) selectedProduct?.salePrice?.toString().orEmpty() else selectedProduct?.costPrice?.toString().orEmpty()) }
  var note by remember { mutableStateOf("") }
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (type == EntryType.SALE) "فاتورة مبيعات جديدة" else "فاتورة مشتريات جديدة") },
    text = {
      LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("اختر المنتج", color = Gold) }
        items(state.products) { p ->
          OutlinedButton(onClick = { selectedProduct = p; price = if (type == EntryType.SALE) p.salePrice.toString() else p.costPrice.toString() }, modifier = Modifier.fillMaxWidth()) {
            Text((if (selectedProduct?.id == p.id) "✓ " else "") + "${p.name} — متاح ${p.quantity}")
          }
        }
        item {
          Text("الحساب (اختياري)", color = Gold)
          parties.forEach { p ->
            TextButton(onClick = { selectedParty = p }) { Text((if (selectedParty?.id == p.id) "✓ " else "") + p.name) }
          }
          NumberField("الكمية", qty) { qty = it }
          NumberField("سعر الوحدة", price) { price = it }
          OutlinedTextField(note, { note = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
          Text("الإجمالي: ${money((qty.toIntOrNull() ?: 0) * (price.toDoubleOrNull() ?: 0.0))}", color = Gold, fontWeight = FontWeight.Bold)
        }
      }
    },
    confirmButton = { Button(onClick = { save(selectedParty, selectedProduct, qty.toIntOrNull() ?: 0, price.toDoubleOrNull() ?: 0.0, note) }) { Text("حفظ الفاتورة") } },
    dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
  )
}

@Composable
private fun PartiesPage(customers: Boolean, state: AccountsState, store: AccountsStore) {
  var dialog by remember { mutableStateOf(false) }
  val parties = if (customers) state.customers else state.suppliers
  Box(Modifier.fillMaxSize()) {
    LazyColumn(Modifier.padding(12.dp)) {
      if (parties.isEmpty()) item { EmptyText(if (customers) "لا يوجد عملاء" else "لا يوجد موردون") }
      items(parties) { p -> StandardCard { Text(p.name, color = Gold, fontWeight = FontWeight.Bold); Text(p.phone); Text(p.address, color = Color.Gray) } }
    }
    FloatingActionButton(onClick = { dialog = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp), containerColor = Gold) { Icon(Icons.Default.Add, null) }
  }
  if (dialog) PartyDialog(if (customers) "إضافة عميل" else "إضافة مورد", { dialog = false }) { n, p, a -> store.addParty(customers, n, p, a); dialog = false }
}

@Composable
private fun PartyDialog(title: String, dismiss: () -> Unit, save: (String, String, String) -> Unit) {
  var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var address by remember { mutableStateOf("") }
  AlertDialog(onDismissRequest = dismiss, title = { Text(title) }, text = {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      OutlinedTextField(name, { name = it }, label = { Text("الاسم") })
      OutlinedTextField(phone, { phone = it }, label = { Text("رقم الهاتف") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
      OutlinedTextField(address, { address = it }, label = { Text("العنوان") })
    }
  }, confirmButton = { Button(onClick = { save(name, phone, address) }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = dismiss) { Text("إلغاء") } })
}

@Composable
private fun InventoryPage(state: AccountsState, store: AccountsStore) {
  var dialog by remember { mutableStateOf(false) }
  Box(Modifier.fillMaxSize()) {
    LazyColumn(Modifier.padding(12.dp)) {
      item { Text(state.cloudStatus, color = Gold, modifier = Modifier.padding(8.dp)) }
      if (state.products.isEmpty()) item { EmptyText("لا توجد منتجات. أضف منتجًا أو انتظر المزامنة.") }
      items(state.products) { p -> StandardCard {
        Text(p.name, color = Gold, fontWeight = FontWeight.Bold)
        Text("الكمية: ${p.quantity} | شراء: ${money(p.costPrice)} | بيع: ${money(p.salePrice)}")
        if (p.quantity <= 3) Text("تنبيه: المخزون منخفض", color = Color(0xFFFF6B6B))
      } }
    }
    FloatingActionButton(onClick = { dialog = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp), containerColor = Gold) { Icon(Icons.Default.Add, null) }
  }
  if (dialog) ProductDialog({ dialog = false }) { n, q, c, p -> store.addProduct(n, q, c, p); dialog = false }
}

@Composable
private fun ProductDialog(dismiss: () -> Unit, save: (String, Int, Double, Double) -> Unit) {
  var name by remember { mutableStateOf("") }; var qty by remember { mutableStateOf("0") }; var cost by remember { mutableStateOf("0") }; var price by remember { mutableStateOf("0") }
  AlertDialog(onDismissRequest = dismiss, title = { Text("إضافة صنف محلي") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    OutlinedTextField(name, { name = it }, label = { Text("اسم الصنف") })
    NumberField("الكمية", qty) { qty = it }; NumberField("سعر الشراء", cost) { cost = it }; NumberField("سعر البيع", price) { price = it }
  } }, confirmButton = { Button(onClick = { save(name, qty.toIntOrNull() ?: 0, cost.toDoubleOrNull() ?: 0.0, price.toDoubleOrNull() ?: 0.0) }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = dismiss) { Text("إلغاء") } })
}

@Composable
private fun CashPage(state: AccountsState, store: AccountsStore, snackbar: SnackbarHostState) {
  var type by remember { mutableStateOf<EntryType?>(null) }
  Column(Modifier.fillMaxSize().padding(12.dp)) {
    StandardCard { Text("رصيد الصندوق", color = Color.Gray); Text(money(state.cashBalance), color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Bold) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      Button({ type = EntryType.RECEIPT }, Modifier.weight(1f)) { Text("سند قبض") }
      OutlinedButton({ type = EntryType.PAYMENT }, Modifier.weight(1f)) { Text("سند صرف") }
    }
    EntryList(state.entries.filter { it.type == EntryType.RECEIPT || it.type == EntryType.PAYMENT }, store)
  }
  type?.let { SimpleEntryDialog(it, { type = null }) { amount, note -> store.recordMovement(it, null, null, 0, 0.0, amount, note); type = null } }
}

@Composable
private fun SimpleEntryPage(type: EntryType, state: AccountsState, store: AccountsStore, snackbar: SnackbarHostState) {
  var dialog by remember { mutableStateOf(false) }
  Box(Modifier.fillMaxSize()) {
    EntryList(state.entries.filter { it.type == type }, store)
    FloatingActionButton({ dialog = true }, Modifier.align(Alignment.BottomEnd).padding(20.dp), containerColor = Gold) { Icon(Icons.Default.Add, null) }
  }
  if (dialog) SimpleEntryDialog(type, { dialog = false }) { amount, note -> store.recordMovement(type, null, null, 0, 0.0, amount, note); dialog = false }
}

@Composable
private fun SimpleEntryDialog(type: EntryType, dismiss: () -> Unit, save: (Double, String) -> Unit) {
  var amount by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
  val title = when (type) { EntryType.EXPENSE -> "مصروف جديد"; EntryType.RECEIPT -> "سند قبض"; else -> "سند صرف" }
  AlertDialog(onDismissRequest = dismiss, title = { Text(title) }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    NumberField("المبلغ", amount) { amount = it }; OutlinedTextField(note, { note = it }, label = { Text("البيان") })
  } }, confirmButton = { Button({ save(amount.toDoubleOrNull() ?: 0.0, note) }) { Text("حفظ") } }, dismissButton = { TextButton(dismiss) { Text("إلغاء") } })
}

@Composable
private fun ReportsPage(state: AccountsState, store: AccountsStore) {
  LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
    item {
      StandardCard {
        Text("ملخص النشاط", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        ReportLine("إجمالي المبيعات", state.salesTotal)
        ReportLine("إجمالي المشتريات", state.purchasesTotal)
        ReportLine("المصروفات", state.expensesTotal)
        ReportLine("مجمل الربح التقريبي", state.salesTotal - state.purchasesTotal - state.expensesTotal)
        ReportLine("رصيد الصندوق", state.cashBalance)
        Text("عدد الأصناف: ${state.products.size} | العملاء: ${state.customers.size} | الموردون: ${state.suppliers.size}")
      }
      Text("آخر الحركات", color = Gold, modifier = Modifier.padding(8.dp))
    }
    items(state.entries.take(20)) { EntryCard(it, store) }
  }
}

@Composable
private fun UsersPage(state: AccountsState, store: AccountsStore) {
  var showAdd by remember { mutableStateOf(false) }
  Box(Modifier.fillMaxSize()) {
    LazyColumn(Modifier.padding(12.dp)) {
      item {
        Text("كل موظف يدخل من نسخة الموظف بكود وPIN خاصين به", color = Gold, modifier = Modifier.padding(8.dp))
      }
      if (state.staff.isEmpty()) item { EmptyText("لا يوجد موظفون حتى الآن") }
      items(state.staff, key = { it.id }) { user ->
        StandardCard {
          Text(user.name, color = Gold, fontWeight = FontWeight.Bold)
          Text("كود الدخول: ${user.loginCode}")
          Text("الصلاحيات: ${user.permissions.joinToString("، ") { permissionName(it) }}", color = Color.Gray)
          OutlinedButton(onClick = { store.setStaffActive(user, !user.active) }) {
            Text(if (user.active) "إيقاف الموظف" else "إعادة تفعيل الموظف")
          }
        }
      }
    }
    FloatingActionButton(onClick = { showAdd = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp), containerColor = Gold) {
      Icon(Icons.Default.Add, null)
    }
  }
  if (showAdd) AddStaffDialog({ showAdd = false }) { name, code, pin, permissions ->
    store.saveStaff(name, code, pin, permissions); showAdd = false
  }
}

@Composable
private fun AddStaffDialog(dismiss: () -> Unit, save: (String, String, String, Set<AppPermission>) -> Unit) {
  var name by remember { mutableStateOf("") }
  var code by remember { mutableStateOf("") }
  var pin by remember { mutableStateOf("") }
  var selected by remember { mutableStateOf(setOf(AppPermission.SALES)) }
  val selectable = AppPermission.entries.filterNot { it == AppPermission.MANAGE_USERS || it == AppPermission.SETTINGS }
  AlertDialog(
    onDismissRequest = dismiss,
    title = { Text("إضافة موظف وصلاحياته") },
    text = {
      LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { OutlinedTextField(name, { name = it }, label = { Text("اسم الموظف") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(code, { code = it }, label = { Text("كود الدخول") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(pin, { pin = it.filter(Char::isDigit) }, label = { Text("PIN أربعة أرقام أو أكثر") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()) }
        item { Text("حدد الصلاحيات", color = Gold, fontWeight = FontWeight.Bold) }
        items(selectable) { permission ->
          Row(Modifier.fillMaxWidth().clickable {
            selected = if (permission in selected) selected - permission else selected + permission
          }, verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = permission in selected, onCheckedChange = { checked ->
              selected = if (checked) selected + permission else selected - permission
            })
            Text(permissionName(permission))
          }
        }
      }
    },
    confirmButton = { Button(onClick = { save(name, code, pin, selected) }, enabled = name.isNotBlank() && code.isNotBlank() && pin.length >= 4) { Text("حفظ الموظف") } },
    dismissButton = { TextButton(onClick = dismiss) { Text("إلغاء") } }
  )
}

@Composable
private fun SettingsPage(state: AccountsState, store: AccountsStore) {
  val context = LocalContext.current
  Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    StandardCard { Text("حالة الربط", color = Gold, fontWeight = FontWeight.Bold); Text(state.cloudStatus); Text("يتم إرسال الكمية وحالة التوفر فقط، ولا يتم إرسال أسعار برنامج الحسابات.", color = Color.Gray) }
    Button(onClick = {
      val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, store.backupJson()); putExtra(Intent.EXTRA_SUBJECT, "نسخة احتياطية VIB Accounts") }
      context.startActivity(Intent.createChooser(send, "حفظ أو مشاركة النسخة الاحتياطية"))
    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Backup, null); Spacer(Modifier.width(8.dp)); Text("نسخ احتياطي للبيانات") }
    StandardCard {
      Text("معلومات النسخة", color = Gold, fontWeight = FontWeight.Bold)
      Text("VIB Accounts 1.0.0")
      Text("معرّف مستقل: com.vib.alaaelgndy.accounts", color = Color.Gray)
      Text("كلمة المرور المبدئية: 1234", color = Color.Gray)
    }
    OutlinedButton(onClick = { store.signOut() }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الخروج") }
  }
}

@Composable
private fun EntryList(entries: List<LedgerEntry>, store: AccountsStore) {
  LazyColumn(Modifier.padding(12.dp)) {
    if (entries.isEmpty()) item { EmptyText("لا توجد حركات مسجلة") }
    items(entries, key = { it.id }) { EntryCard(it, store) }
  }
}

@Composable
private fun EntryCard(entry: LedgerEntry, store: AccountsStore) {
  StandardCard {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Column(Modifier.weight(1f)) {
        Text(typeName(entry.type), color = Gold, fontWeight = FontWeight.Bold)
        Text(listOf(entry.productName, entry.partyName, entry.note).filter { it.isNotBlank() }.joinToString(" — "))
        Text(date(entry.timestamp) + if (entry.createdByName.isBlank()) "" else " — بواسطة ${entry.createdByName}", color = Color.Gray, fontSize = 12.sp)
        if (entry.cancelled) Text("ملغاة", color = Color(0xFFFF7B7B), fontWeight = FontWeight.Bold)
      }
      Column(horizontalAlignment = Alignment.End) {
        Text(money(entry.amount), fontWeight = FontWeight.Bold)
        if (!entry.cancelled) TextButton(onClick = { store.reverse(entry) }) { Text("إلغاء الحركة", color = Color(0xFFFF7B7B)) }
      }
    }
  }
}

@Composable
private fun StandardCard(content: @Composable ColumnScope.() -> Unit) {
  Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, Color(0xFF3B3B3B)), shape = RoundedCornerShape(14.dp)) {
    Column(Modifier.padding(14.dp), content = content)
  }
}

@Composable private fun EmptyText(text: String) { Text(text, color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(30.dp)) }
@Composable private fun ReportLine(label: String, value: Double) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Text(money(value), color = Gold) }; HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Color(0xFF333333)) }
@Composable private fun NumberField(label: String, value: String, change: (String) -> Unit) { OutlinedTextField(value, { change(it.filter { c -> c.isDigit() || c == '.' }) }, label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth()) }

private fun typeName(type: EntryType) = when (type) { EntryType.SALE -> "مبيعات"; EntryType.PURCHASE -> "مشتريات"; EntryType.EXPENSE -> "مصروف"; EntryType.RECEIPT -> "قبض"; EntryType.PAYMENT -> "صرف" }
private fun permissionName(permission: AppPermission) = when (permission) {
  AppPermission.SALES -> "المبيعات"
  AppPermission.PURCHASES -> "المشتريات"
  AppPermission.CUSTOMERS -> "العملاء"
  AppPermission.SUPPLIERS -> "الموردون"
  AppPermission.CASH_RECEIPT -> "سندات القبض"
  AppPermission.CASH_PAYMENT -> "سندات الصرف"
  AppPermission.EXPENSES -> "المصروفات"
  AppPermission.INVENTORY -> "عرض المخزون"
  AppPermission.REPORTS -> "التقارير والأرباح"
  AppPermission.CANCEL_ENTRY -> "إلغاء الحركات"
  AppPermission.MANAGE_USERS -> "إدارة الموظفين"
  AppPermission.SETTINGS -> "الإعدادات"
}
private fun money(value: Double) = NumberFormat.getNumberInstance(Locale("ar", "EG")).apply { maximumFractionDigits = 2 }.format(value) + " ج.م"
private fun date(value: Long) = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar", "EG")).format(Date(value))
