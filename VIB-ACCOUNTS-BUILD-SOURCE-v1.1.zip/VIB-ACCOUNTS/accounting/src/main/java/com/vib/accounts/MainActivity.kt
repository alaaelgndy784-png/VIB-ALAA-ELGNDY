package com.vib.accounts

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent {
      MaterialTheme(
        colorScheme = darkColorScheme(
          primary = Color(0xFFD4AF37),
          secondary = Color(0xFFF2D675),
          background = Color(0xFF090909),
          surface = Color(0xFF171717),
          onPrimary = Color.Black,
          onBackground = Color.White,
          onSurface = Color.White
        )
      ) { VibAccountsApp() }
    }
  }
}
