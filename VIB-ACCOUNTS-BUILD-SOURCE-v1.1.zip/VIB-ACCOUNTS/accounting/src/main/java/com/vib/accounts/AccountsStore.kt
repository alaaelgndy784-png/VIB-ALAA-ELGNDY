package com.vib.accounts

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.security.MessageDigest

data class StockItem(
  val id: String = UUID.randomUUID().toString(),
  val name: String,
  val quantity: Int = 0,
  val costPrice: Double = 0.0,
  val salePrice: Double = 0.0
)

data class Party(
  val id: String = UUID.randomUUID().toString(),
  val name: String,
  val phone: String = "",
  val address: String = "",
  val balance: Double = 0.0
)

enum class EntryType { SALE, PURCHASE, EXPENSE, RECEIPT, PAYMENT }

enum class AppPermission {
  SALES, PURCHASES, CUSTOMERS, SUPPLIERS, CASH_RECEIPT, CASH_PAYMENT,
  EXPENSES, INVENTORY, REPORTS, CANCEL_ENTRY, MANAGE_USERS, SETTINGS
}

data class StaffAccount(
  val id: String = UUID.randomUUID().toString(),
  val name: String,
  val loginCode: String,
  val pinHash: String,
  val permissions: Set<AppPermission> = setOf(AppPermission.SALES),
  val active: Boolean = true
)

data class SignedInUser(
  val id: String,
  val name: String,
  val isManager: Boolean,
  val permissions: Set<AppPermission>
) {
  fun can(permission: AppPermission) = isManager || permission in permissions
}

data class LedgerEntry(
  val id: String = UUID.randomUUID().toString(),
  val type: EntryType,
  val partyId: String = "",
  val partyName: String = "",
  val productId: String = "",
  val productName: String = "",
  val quantity: Int = 0,
  val unitPrice: Double = 0.0,
  val amount: Double,
  val note: String = "",
  val timestamp: Long = System.currentTimeMillis(),
  val createdById: String = "",
  val createdByName: String = "",
  val deviceRole: String = BuildConfig.APP_ROLE,
  val cancelled: Boolean = false
)

data class AccountsState(
  val products: List<StockItem> = emptyList(),
  val customers: List<Party> = emptyList(),
  val suppliers: List<Party> = emptyList(),
  val entries: List<LedgerEntry> = emptyList(),
  val staff: List<StaffAccount> = emptyList(),
  val signedInUser: SignedInUser? = null,
  val cloudStatus: String = "جاري الاتصال بالمخزون..."
) {
  val salesTotal get() = entries.filter { !it.cancelled && it.type == EntryType.SALE }.sumOf { it.amount }
  val purchasesTotal get() = entries.filter { !it.cancelled && it.type == EntryType.PURCHASE }.sumOf { it.amount }
  val expensesTotal get() = entries.filter { !it.cancelled && it.type == EntryType.EXPENSE }.sumOf { it.amount }
  val receiptsTotal get() = entries.filter { !it.cancelled && it.type == EntryType.RECEIPT }.sumOf { it.amount }
  val paymentsTotal get() = entries.filter { !it.cancelled && it.type == EntryType.PAYMENT }.sumOf { it.amount }
  val cashBalance get() = salesTotal + receiptsTotal - purchasesTotal - expensesTotal - paymentsTotal
}

class AccountsStore(private val context: Context) {
  private val prefs = context.getSharedPreferences("vib_accounts", Context.MODE_PRIVATE)
  private val scope = CoroutineScope(Dispatchers.IO)
  private val _state = MutableStateFlow(loadLocal())
  val state = _state.asStateFlow()
  private var db: FirebaseFirestore? = null
  private val cloudProductIds = mutableSetOf<String>()
  private val businessId = "vib-main"

  init { connectAndLoadStock() }

  private fun connectAndLoadStock() {
    scope.launch {
      try {
        if (FirebaseApp.getApps(context).isEmpty()) {
          FirebaseApp.initializeApp(
            context,
            FirebaseOptions.Builder()
              .setProjectId("vib-alaaelgndy")
              .setApiKey("AIzaSyASUi-6xrJDrd8NWunLvEWvD3uR08LOuLs")
              .setApplicationId("1:984952125141:android:9f0c3e79cdebbf0b6f945c")
              .setStorageBucket("vib-alaaelgndy.firebasestorage.app")
              .build()
          )
        }
        db = FirebaseFirestore.getInstance()
        listenToStaff()
        listenToEntries()
        db?.collection("products")?.addSnapshotListener { snapshot, error ->
          if (error != null) {
            update { it.copy(cloudStatus = "تعذر الاتصال - البيانات المحلية تعمل") }
            return@addSnapshotListener
          }
          val remote = snapshot?.documents?.map { doc ->
            cloudProductIds.add(doc.id)
            StockItem(
              id = doc.id,
              name = doc.getString("name").orEmpty(),
              quantity = (doc.getLong("stockQuantity") ?: 0L).toInt(),
              costPrice = localProduct(doc.id)?.costPrice ?: 0.0,
              salePrice = localProduct(doc.id)?.salePrice ?: (doc.getDouble("price") ?: 0.0)
            )
          }.orEmpty().filter { it.name.isNotBlank() }
          if (remote.isNotEmpty()) update { it.copy(products = remote, cloudStatus = "المخزون متصل ومحدّث") }
          else update { it.copy(cloudStatus = "متصل - لا توجد منتجات على السحابة") }
        }
      } catch (_: Exception) {
        update { it.copy(cloudStatus = "وضع محلي - راجع إعدادات الإنترنت") }
      }
    }
  }

  fun signIn(code: String, pin: String, result: (String?) -> Unit) {
    if (BuildConfig.APP_ROLE == "MANAGER" && code.trim().equals("admin", true) && pin == "1234") {
      update { it.copy(signedInUser = SignedInUser("manager", "المدير", true, AppPermission.entries.toSet())) }
      result(null); return
    }
    val match = _state.value.staff.firstOrNull {
      it.active && it.loginCode.equals(code.trim(), true) && it.pinHash == hash(pin)
    }
    if (match == null) result("بيانات الدخول غير صحيحة أو الحساب موقوف")
    else {
      update { it.copy(signedInUser = SignedInUser(match.id, match.name, false, match.permissions)) }
      result(null)
    }
  }

  fun signOut() = update { it.copy(signedInUser = null) }

  fun saveStaff(name: String, loginCode: String, pin: String, permissions: Set<AppPermission>) {
    if (name.isBlank() || loginCode.isBlank() || pin.length < 4) return
    val account = StaffAccount(name = name.trim(), loginCode = loginCode.trim(), pinHash = hash(pin), permissions = permissions)
    db?.collection("businesses")?.document(businessId)?.collection("staff")?.document(account.id)?.set(
      mapOf("name" to account.name, "loginCode" to account.loginCode, "pinHash" to account.pinHash,
        "permissions" to account.permissions.map { it.name }, "active" to true)
    )
    update { it.copy(staff = it.staff + account) }
  }

  fun setStaffActive(account: StaffAccount, active: Boolean) {
    db?.collection("businesses")?.document(businessId)?.collection("staff")?.document(account.id)
      ?.set(mapOf("active" to active), SetOptions.merge())
  }

  private fun listenToStaff() {
    db?.collection("businesses")?.document(businessId)?.collection("staff")?.addSnapshotListener { snapshot, _ ->
      val users = snapshot?.documents?.mapNotNull { doc ->
        val name = doc.getString("name").orEmpty(); if (name.isBlank()) return@mapNotNull null
        StaffAccount(doc.id, name, doc.getString("loginCode").orEmpty(), doc.getString("pinHash").orEmpty(),
          (doc.get("permissions") as? List<*>)?.mapNotNull { runCatching { AppPermission.valueOf(it.toString()) }.getOrNull() }?.toSet().orEmpty(),
          doc.getBoolean("active") != false)
      }.orEmpty()
      update { it.copy(staff = users) }
    }
  }

  private fun listenToEntries() {
    db?.collection("businesses")?.document(businessId)?.collection("entries")?.addSnapshotListener { snapshot, _ ->
      val remote = snapshot?.documents?.mapNotNull { doc ->
        val type = runCatching { EntryType.valueOf(doc.getString("type").orEmpty()) }.getOrNull() ?: return@mapNotNull null
        LedgerEntry(id = doc.id, type = type, partyId = doc.getString("partyId").orEmpty(), partyName = doc.getString("partyName").orEmpty(),
          productId = doc.getString("productId").orEmpty(), productName = doc.getString("productName").orEmpty(),
          quantity = (doc.getLong("quantity") ?: 0).toInt(), unitPrice = doc.getDouble("unitPrice") ?: 0.0,
          amount = doc.getDouble("amount") ?: 0.0, note = doc.getString("note").orEmpty(), timestamp = doc.getLong("timestamp") ?: 0,
          createdById = doc.getString("createdById").orEmpty(), createdByName = doc.getString("createdByName").orEmpty(),
          deviceRole = doc.getString("deviceRole").orEmpty(), cancelled = doc.getBoolean("cancelled") == true)
      }.orEmpty().sortedByDescending { it.timestamp }
      if (remote.isNotEmpty()) update { it.copy(entries = remote) }
    }
  }

  fun addParty(customer: Boolean, name: String, phone: String, address: String) {
    if (name.isBlank()) return
    val party = Party(name = name.trim(), phone = phone.trim(), address = address.trim())
    update {
      if (customer) it.copy(customers = it.customers + party)
      else it.copy(suppliers = it.suppliers + party)
    }
  }

  fun addProduct(name: String, quantity: Int, cost: Double, price: Double) {
    if (name.isBlank()) return
    update { it.copy(products = it.products + StockItem(name = name.trim(), quantity = quantity, costPrice = cost, salePrice = price)) }
  }

  fun recordMovement(
    type: EntryType,
    party: Party?,
    product: StockItem?,
    quantity: Int,
    unitPrice: Double,
    amount: Double,
    note: String
  ): String? {
    val user = _state.value.signedInUser ?: return "سجّل الدخول أولًا"
    val required = when (type) {
      EntryType.SALE -> AppPermission.SALES; EntryType.PURCHASE -> AppPermission.PURCHASES
      EntryType.EXPENSE -> AppPermission.EXPENSES; EntryType.RECEIPT -> AppPermission.CASH_RECEIPT
      EntryType.PAYMENT -> AppPermission.CASH_PAYMENT
    }
    if (!user.can(required)) return "ليس لديك صلاحية لهذه العملية"
    if ((type == EntryType.SALE || type == EntryType.PURCHASE) && product == null) return "اختر المنتج"
    if (type == EntryType.SALE && product != null && quantity > product.quantity) return "الكمية المطلوبة أكبر من المخزون"
    val finalAmount = if (type == EntryType.SALE || type == EntryType.PURCHASE) quantity * unitPrice else amount
    if (finalAmount <= 0) return "أدخل قيمة صحيحة"
    val entry = LedgerEntry(
      type = type,
      partyId = party?.id.orEmpty(), partyName = party?.name.orEmpty(),
      productId = product?.id.orEmpty(), productName = product?.name.orEmpty(),
      quantity = quantity, unitPrice = unitPrice, amount = finalAmount, note = note.trim(),
      createdById = user.id, createdByName = user.name
    )
    var newQuantity: Int? = null
    update { old ->
      val products = if (product == null) old.products else old.products.map {
        if (it.id != product.id) it else {
          val q = when (type) {
            EntryType.SALE -> it.quantity - quantity
            EntryType.PURCHASE -> it.quantity + quantity
            else -> it.quantity
          }
          newQuantity = q
          it.copy(
            quantity = q,
            costPrice = if (type == EntryType.PURCHASE) unitPrice else it.costPrice,
            salePrice = if (type == EntryType.SALE) unitPrice else it.salePrice
          )
        }
      }
      old.copy(products = products, entries = listOf(entry) + old.entries)
    }
    if (product != null && newQuantity != null && product.id in cloudProductIds) syncQuantity(product.id, newQuantity!!)
    syncEntry(entry)
    return null
  }

  fun reverse(entry: LedgerEntry) {
    val user = _state.value.signedInUser ?: return
    if (!user.can(AppPermission.CANCEL_ENTRY)) return
    var sync: Pair<String, Int>? = null
    update { old ->
      val products = old.products.map { p ->
        if (p.id != entry.productId) p else {
          val q = when (entry.type) {
            EntryType.SALE -> p.quantity + entry.quantity
            EntryType.PURCHASE -> p.quantity - entry.quantity
            else -> p.quantity
          }
          sync = p.id to q
          p.copy(quantity = q)
        }
      }
      old.copy(products = products, entries = old.entries.map { if (it.id == entry.id) it.copy(cancelled = true) else it })
    }
    sync?.takeIf { it.first in cloudProductIds }?.let { syncQuantity(it.first, it.second) }
    db?.collection("businesses")?.document(businessId)?.collection("entries")?.document(entry.id)
      ?.set(mapOf("cancelled" to true, "cancelledBy" to user.name, "cancelledAt" to System.currentTimeMillis()), SetOptions.merge())
  }

  private fun syncEntry(entry: LedgerEntry) {
    val data = mapOf("type" to entry.type.name, "partyId" to entry.partyId, "partyName" to entry.partyName,
      "productId" to entry.productId, "productName" to entry.productName, "quantity" to entry.quantity,
      "unitPrice" to entry.unitPrice, "amount" to entry.amount, "note" to entry.note, "timestamp" to entry.timestamp,
      "createdById" to entry.createdById, "createdByName" to entry.createdByName,
      "deviceRole" to entry.deviceRole, "cancelled" to false)
    db?.collection("businesses")?.document(businessId)?.collection("entries")?.document(entry.id)?.set(data)
  }

  private fun syncQuantity(productId: String, quantity: Int) {
    scope.launch {
      try {
        db?.collection("products")?.document(productId)?.set(
          mapOf("stockQuantity" to quantity, "inStock" to (quantity > 0)),
          SetOptions.merge()
        )
      } catch (_: Exception) {
        update { it.copy(cloudStatus = "الحركة محفوظة محليًا - المزامنة مؤجلة") }
      }
    }
  }

  fun backupJson(): String {
    val s = _state.value
    return JSONObject().apply {
      put("createdAt", System.currentTimeMillis())
      put("products", productsJson(s.products))
      put("customers", partiesJson(s.customers))
      put("suppliers", partiesJson(s.suppliers))
      put("entries", entriesJson(s.entries))
      put("staff", staffJson(s.staff))
    }.toString(2)
  }

  private fun localProduct(id: String) = _state.value.products.firstOrNull { it.id == id }

  private fun update(block: (AccountsState) -> AccountsState) {
    _state.value = block(_state.value)
    saveLocal(_state.value)
  }

  private fun saveLocal(s: AccountsState) {
    prefs.edit()
      .putString("products", productsJson(s.products).toString())
      .putString("customers", partiesJson(s.customers).toString())
      .putString("suppliers", partiesJson(s.suppliers).toString())
      .putString("entries", entriesJson(s.entries).toString())
      .putString("staff", staffJson(s.staff).toString())
      .apply()
  }

  private fun loadLocal(): AccountsState = try {
    AccountsState(
      products = parseProducts(prefs.getString("products", "[]")!!),
      customers = parseParties(prefs.getString("customers", "[]")!!),
      suppliers = parseParties(prefs.getString("suppliers", "[]")!!),
      entries = parseEntries(prefs.getString("entries", "[]")!!),
      staff = parseStaff(prefs.getString("staff", "[]")!!)
    )
  } catch (_: Exception) { AccountsState() }

  private fun productsJson(list: List<StockItem>) = JSONArray().apply { list.forEach { p -> put(JSONObject().apply {
    put("id", p.id); put("name", p.name); put("quantity", p.quantity); put("costPrice", p.costPrice); put("salePrice", p.salePrice)
  }) } }
  private fun partiesJson(list: List<Party>) = JSONArray().apply { list.forEach { p -> put(JSONObject().apply {
    put("id", p.id); put("name", p.name); put("phone", p.phone); put("address", p.address); put("balance", p.balance)
  }) } }
  private fun entriesJson(list: List<LedgerEntry>) = JSONArray().apply { list.forEach { e -> put(JSONObject().apply {
    put("id", e.id); put("type", e.type.name); put("partyId", e.partyId); put("partyName", e.partyName)
    put("productId", e.productId); put("productName", e.productName); put("quantity", e.quantity)
    put("unitPrice", e.unitPrice); put("amount", e.amount); put("note", e.note); put("timestamp", e.timestamp)
    put("createdById", e.createdById); put("createdByName", e.createdByName); put("deviceRole", e.deviceRole); put("cancelled", e.cancelled)
  }) } }
  private fun staffJson(list: List<StaffAccount>) = JSONArray().apply { list.forEach { u -> put(JSONObject().apply {
    put("id", u.id); put("name", u.name); put("loginCode", u.loginCode); put("pinHash", u.pinHash)
    put("permissions", JSONArray(u.permissions.map { it.name })); put("active", u.active)
  }) } }

  private fun parseProducts(raw: String) = JSONArray(raw).let { a -> (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
    StockItem(o.getString("id"), o.getString("name"), o.optInt("quantity"), o.optDouble("costPrice"), o.optDouble("salePrice"))
  } } }
  private fun parseParties(raw: String) = JSONArray(raw).let { a -> (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
    Party(o.getString("id"), o.getString("name"), o.optString("phone"), o.optString("address"), o.optDouble("balance"))
  } } }
  private fun parseEntries(raw: String) = JSONArray(raw).let { a -> (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
    LedgerEntry(o.getString("id"), EntryType.valueOf(o.getString("type")), o.optString("partyId"), o.optString("partyName"),
      o.optString("productId"), o.optString("productName"), o.optInt("quantity"), o.optDouble("unitPrice"),
      o.optDouble("amount"), o.optString("note"), o.optLong("timestamp"), o.optString("createdById"),
      o.optString("createdByName"), o.optString("deviceRole"), o.optBoolean("cancelled"))
  } } }
  private fun parseStaff(raw: String) = JSONArray(raw).let { a -> (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
    val permissions = o.optJSONArray("permissions")?.let { p -> (0 until p.length()).mapNotNull { j -> runCatching { AppPermission.valueOf(p.getString(j)) }.getOrNull() }.toSet() }.orEmpty()
    StaffAccount(o.getString("id"), o.getString("name"), o.getString("loginCode"), o.getString("pinHash"), permissions, o.optBoolean("active", true))
  } } }

  private fun hash(value: String): String = MessageDigest.getInstance("SHA-256")
    .digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}
