plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
}

android {
  namespace = "com.vib.accounts"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.vib.alaaelgndy.accounts"
    minSdk = 24
    targetSdk = 36
    versionCode = 2
    versionName = "1.1.0"
  }
  flavorDimensions += "role"
  productFlavors {
    create("manager") {
      dimension = "role"
      applicationIdSuffix = ".manager"
      versionNameSuffix = "-manager"
      buildConfigField("String", "APP_ROLE", "\"MANAGER\"")
      resValue("string", "app_name", "VIB Accounts - المدير")
    }
    create("staff") {
      dimension = "role"
      applicationIdSuffix = ".staff"
      versionNameSuffix = "-staff"
      buildConfigField("String", "APP_ROLE", "\"STAFF\"")
      resValue("string", "app_name", "VIB Accounts - الموظف")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures { compose = true; buildConfig = true }
}

dependencies {
  implementation(platform(libs.androidx.compose.bom))
  implementation(platform(libs.firebase.bom))
  implementation(libs.androidx.activity.compose)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.firebase.firestore)
  implementation(libs.kotlinx.coroutines.android)
  debugImplementation(libs.androidx.compose.ui.tooling)
}
