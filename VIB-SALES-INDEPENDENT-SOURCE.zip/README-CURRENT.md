# VIB Sales — source update (28 September 2026)

The manager home now follows the black/gold reference with separate tiles for vehicles, staff, sales, purchases, customers, suppliers, inventory, expenses, cash, and profit reports. The employee sees only sales and branch stock. Existing management/settings screens remain accessible to the owner.

New manual and camera purchase invoices, and new sales invoices, support multiple products in one invoice. `invoiceHeaders` holds the invoice, item snapshots, total, paid, due, and payment status. Individual `purchases` / `sales` records remain for existing stock, return and profit history and carry `invoiceId`; the UI displays the header once and hides its individual rows. Old single-product records still appear in a clearly marked legacy section. Entire new invoices can be returned atomically. PDF and WhatsApp display all lines and payment amounts.

Owner sales can be on credit when a customer account is selected; the customer's balance increases by the unpaid amount. Employee sales are cash only in this version. Purchases add unpaid amounts to the supplier balance. Cost is captured per sale line at sale time, including corrected old invoices. Profit report counts grouped invoices once, sums their line revenue and captured cost, and excludes historic lines without recorded cost; the report has day, week, month and all-time periods. These profit figures are estimates when old cost data is incomplete. Inventory costing still uses the last recorded purchase cost, not weighted average.

Before use: deploy `firebase/firestore.rules` to the intended Firebase project and test owner/employee permissions. Rules introduce `invoiceHeaders` and `vehicles`, and permit the employee's sale line to refer to its invoice header. The stock and payment transactions need an end-to-end build and device test. The SDK is not present in the current environment, so this source package has not been compiled into APKs. No GitHub or Firebase changes have been published by this package. The repository build workflow also needs its overrides removed or updated; the packaged workflow has been corrected to use this source without self-registering an owner. Existing owner accounts must already be provisioned.

Known accounting boundary: `paid` and `due` are saved on invoices and customer/supplier balances are updated for credit. Payment and refund amounts are not automatically posted to the separate cash-box ledger. Reconcile cash-box movements separately before treating its balance as actual cash. Historic invoices without cost cannot yield an exact profit. Do not treat this package as an approved production release until the build and end-to-end tests pass.

## Continuation 29 September 2026

The dashboard now has raised black/gold tiles and a "الضبط والإصلاحات" entry. Invoice settings include tax ID, commercial registration, a footer, and a custom logo. Grouped invoice items print with sequential numbers, and thermal page length scales with the item count. A denied save for grouped sales or vehicles now identifies the likely Firestore-rule or account-permission problem.

This is based on the newer `codex/vib-sales-dashboard-invoices` branch, commit `05ec1e4`, rather than the older `main` source. Its GitHub Actions build #52 succeeded, but there has been no device test of this continuation. The new `invoiceHeaders` and `vehicles` rules have not been verified as deployed. Firebase console access was declined in the browser, so do not claim those saves work until the rules are checked and published by an authorized owner. The source has not been uploaded to GitHub or built into a new APK.

## 2026-09-29 invoice/search/save repair
- Sales invoice: one search button at the top adds products to one numbered invoice (1, 2, 3...).
- Purchase invoice: one search button at the top adds products to one numbered invoice; quantity and purchase price are editable per row.
- Manager grouped sales are saved as one document in the existing `sales` collection, with `items`, total, paid, due, and payment status.
- Manager grouped purchases are saved as one document in the existing `purchases` collection, with `items`, total, paid, due, and payment status.
- Manager vehicle records are stored under `settings/main.vehicles` instead of a new `vehicles` collection, so the manager save no longer depends on newly deployed Firestore collection rules.
- Grouped invoice PDF output prints sequential rows and uses a table on A4.
- Grouped returns reverse stock, due balances, and the paid cash movement.
- Profit reporting understands grouped sales stored as one invoice document.

## 2026-09-29 employee invoice display/report follow-up
- Employee sales keep their permission-compatible `invoiceHeaders` plus `sales` line records. The sales list reads the header and hides its child lines, so one transaction appears once with total, paid, due, and status.
- The sales PDF report reads both manager invoice documents and employee invoice headers. Legacy single-item sales remain included; child lines are excluded to avoid double counting.
- Printing an employee invoice updates `invoiceHeaders/{id}` instead of creating an unrelated `sales/{id}` document. Detail and sharing use the header's item list.
- Existing camera purchases from the 26 September line-per-document format remain legacy records. New manual and camera purchases use a single `purchases` document with `items`. A historical migration needs separate review of partial returns and duplicate supplier invoice numbers.
- Required device/Firebase checks: manager and employee three-item invoices each appear once in the list and report; PDF totals match; employee print marks the header only; cash and credit purchases, returns, permissions, and previously saved legacy invoices remain correct. The source has not been compiled or deployed in this environment.

## 2026-09-29 visible invoice correction
- Manual sale and purchase dialogs keep payment and total/due/status visible beneath the scrolling numbered item list; every added product updates one invoice total.
- Camera purchase review recalculates total/paid/due when quantity, unit cost or paid amount changes.
- Historical scanned purchase rows with the same `scanGroupId` appear together as a read-only combined invoice and PDF. Each old row remains independently returnable in its detail view; this display grouping does not rewrite historic records or infer grouping from a reused supplier invoice number.

## 2026-09-29 employee sales permission follow-up
- A denied `invoiceHeaders` read no longer replaces the entire Sales page with an error. The old sales list and new invoice button stay visible, with a permission banner.
- A denied staff invoice save now explicitly identifies the `invoiceHeaders` / staff sales Firestore rule requirement. This application change does not deploy Firestore rules. Deploy `firebase/firestore.rules` to project `vib-sales`, then verify a two-item staff invoice saves and appears once with a matching report/PDF.
